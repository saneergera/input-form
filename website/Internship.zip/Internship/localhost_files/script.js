$(".btn").on("click",function(){
  var name = $("#Username").val();
  var email = $("#Email").val();
  var num = $("#num").val();

  var dataString = 'Username='+ name + 'Email='+ email + 'num='+ password ;
  if(name==''||email==''||contact=='')
  {
  alert("Please Fill All Fields");
  }
  else
  {
  // AJAX Code To Submit Form.
  $.ajax({
  type: "POST",
  url: "data.php",
  data: dataString,
  cache: false,
  success: function(result){
  alert(result);

  }
  });
  }



})
