$(".btn").click(function()
{
  var name = $("#Username").val();
  var email = $("#Email").val();
  var num = $("#num").val();
  console.log(name);
  var dataString = 'Username=' +
    name + '&Email=' + email +
    '&num=' + num;
  if (name == '' || email == '' ||
    num == '')
  {
    alert("Please Fill All Fields");
  }
  else
  {
    // AJAX Code To Submit Form.
    $(".msg").html(
      "<img src='loading.gif' class='img'>"
    );
    $(".msg").css("right", "13%");
    $.ajax(
    {
      type: "POST",
      url: "data.php",
      data: dataString,
      cache: false,
      success: function(result)
      {
        console.log(result);
        if (result ==
          "Number is Invalid"
        )
        {
          console.log('c');
          setTimeout(function()
          {
            $(".msg").html(
              result);
            $(".msg").css(
              "right",
              "5%");
          }, 3000);
        }
        else if (result ==
          "Email is Invalid")
        {
          console.log('b');
          setTimeout(function()
          {
            $(".msg").html(
              result);
            $(".msg").css(
              "right",
              "5%");
          }, 3000);
        }
        else if (result ==
          "You Are Registered"
        )
        {
          console.log('a');
          setTimeout(function()
          {
            $(".msg").html(
              result);
            $(".msg").css(
              "right",
              "2%");
            $(".msg").css(
              "font-size",
              "20px");
          }, 3000);
          setTimeout(function()
          {
            location.reload();
          }, 5000);
        }
      }
    });
  }
})
