<!DOCTYPE html>

<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">


  </head>
  <body>


    <div class="container">
      <div class="msg">
          Register
      </div>


    <div class="container-form">

      <div class="form-item log-in">
        <div class="table">
          <div class="table-cell">

            <form >
              <input name="Username" placeholder="Username" type="text" id="Username" required/>
              <input name="Email" placeholder="Email" type="email" id="Email" required/>
              <input name="num" placeholder="Mobile-number" type="text" id="num"required />
              <span style="
              position: relative;
          top: -45px;
          font-size: 10px;
          left: 6px;
          border: 1px solid #D3D3D3;
          padding-top: 10px;
          color: #777676;
          padding-bottom: 13px;
          padding-right: 2px;">+91</span>
              <input type="button" name="" class="btn" value='&#9654'>
            </form>


          </div>
        </div>
      </div>

      </div>
    </div>
  </div>
</div>
<script
  src="https://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script>
<script type="text/javascript" src="script.js">

</script>


  </body>
</html>
