<?php
$timezone = date_default_timezone_set("Asia/Kolkata");
$conn     = mysqli_connect("localhost", "root", "root", "info");
if (!$conn) {
        echo error;
}
$name            = $_POST['Username'];
$email           = $_POST['Email'];
$phone           = $_POST['num'];
$log_error_array = array();
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo ("Email is Invalid");
} else if (!preg_match('/^[0-9]{10}+$/', $phone)) {
        echo ("Number is Invalid");
} else {
        $sql = "INSERT INTO enteries
  VALUES ('','$name', '$email', '$phone')";
        if (mysqli_query($conn, $sql)) {
                echo "You Are Registered";
        } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
}
?>
